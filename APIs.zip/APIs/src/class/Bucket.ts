export class Bucket {
    name: string;
    region: string;

    constructor() {
        this.name = "";
        this.region = "";
    }
}

