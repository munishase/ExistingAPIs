export class NetsuiteCredentials {
    AccountNumber: string;
    Username: string;
    Password: string;
    RoleId: string;
    constructor() {
        this.AccountNumber = "";
        this.Username = "";
        this.Password = "";
        this.RoleId = "";
    }
}

