export class NetsuiteClient {
    RecordType: string;
    CustomForm: string;
    EntityId: string;
    ClientId: string;
    ClientName: string;
    Currency: string;
    ACN: string;
    Address: string;
    Type: string;
    Status: string;
    constructor() {
        this.RecordType = "";
        this.CustomForm = "";
        this.EntityId = "";
        this.ClientId = "";
        this.ClientName = "";
        this.Currency = "";
        this.ACN = "";
        this.Address = "";
        this.Type = "";
        this.Status = "";
    }
}

