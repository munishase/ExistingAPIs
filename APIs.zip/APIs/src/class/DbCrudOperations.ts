import { EnumPartOf } from '../Enum/EnumPartOf'
import { Logger } from './Logger'
import { EnumModule } from '../Enum/EnumModule';


//this class will contain all the functions, used to interation with db
class DbCrudOperations {

    //generate random password with length as input param
    saveRecord(record: any) {
      console.log(record)
    }
    
}



export default new DbCrudOperations();