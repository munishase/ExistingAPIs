export class Stitchdata {
    PartnerId: string;
    PartnerSecret: string;
    GrantType: string;
    ContentType: string;
    AuthorizationCode: string;
    Token: string;
    TokenType: string;
    AccountId: string;
    constructor() {
        this.PartnerId = "";
        this.PartnerSecret = "";
        this.GrantType = ""
        this.ContentType = ""
        this.AuthorizationCode = ""
        this.Token = ""
        this.TokenType = ""
        this.AccountId = ""
    }
}

