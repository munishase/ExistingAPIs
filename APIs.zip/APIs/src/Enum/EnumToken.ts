export enum EnumToken {
  TenantToken = "TenantToken",
  StorageGridToken = "StorageGridToken",
  VeeamToken = "VeeamToken",
  StitchdataToken = "StitchdataToken",
  ActivePortToken = "ActivePortToken",
  XcloudCookie = "connect.sid",
  NetAppToken = "NetAppToken",
  DataikuToken = "DataikuToken"
}