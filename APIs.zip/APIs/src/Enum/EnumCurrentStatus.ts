export enum EnumCurrentStatus {
  Error = "Error",
  Success = "Success"
  }