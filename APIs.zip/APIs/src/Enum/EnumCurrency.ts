export enum EnumCurrency {
  AUD = "1"
  }