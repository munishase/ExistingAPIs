export enum EnumModule {
  Storagegrid = "Storagegrid",
  Netsuite = "Netsuite",
  Veeam = "Veeam",
  Stitchdata = "Stitchdata",
  ActivePort = "ActivePort",
  Xcloud = "Xcloud",
  fluid = "fluid",
  NetApp = "NetApp",
  Dataiku = "Dataiku"
}