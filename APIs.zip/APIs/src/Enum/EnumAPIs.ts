export enum EnumAPIs {
  createclouddxasync = "createclouddxasync",
  createntuasync = "createntuasync"
}