export enum EnumClientType {
  Company = "4",
  Individual = "2"

}