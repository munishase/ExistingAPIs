export enum EnumPartOf {
  Individual = "Individual",
  Group = "Group"
}