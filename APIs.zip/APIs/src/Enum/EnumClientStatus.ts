export enum EnumClientStatus {
  CLIENTLostCustomer = "1",
  CLIENTClosedWon = "2",
  CLIENTRenewal = "3"

  }