export enum EnumSessionForEachRequest {
  UUID = "UUID",
  ApiName = "ApiName"
}